select msg.EVENT_TIMESTAMP, msg.has_bitstream, msg.has_exception, msg.has_userdata, msg.event_srcaddr, msg.exgrp_name, msg.msgflow_name, detail, bd.DATA, bd.ENCODING
from WMB_MSGS msg,
     WMB_BINARY_DATA bd
where (msg.WMB_MSGKEY = bd.WMB_MSGKEY)
and msg.event_timestamp like '2018-11-18 0%'
--and (msg.msgflow_name like '%InsertUpdateCustomer%' or msg.msgflow_name like '%oService%')
--and msg.event_timestamp>'2018-11-18 04:37:30.000'
--and msg.event_timestamp<'2018-11-18 04:37:40.000'
and (bd.data like '%MTU0MjU1OTA1NjcwMg%')
order by msg.event_timestamp desc; 


select * from WMB_MSGS msg, WMB_BINARY_DATA bd
where (msg.WMB_MSGKEY = bd.WMB_MSGKEY)
order by msg.event_timestamp desc; 
 

 
select msg.EVENT_TIMESTAMP, msg.has_bitstream, msg.has_exception, msg.has_userdata, msg.event_srcaddr, msg.exgrp_name, msg.msgflow_name, detail, bd.DATA, bd.ENCODING
from WMB_MSGS msg,
     WMB_BINARY_DATA bd
where (msg.WMB_MSGKEY = bd.WMB_MSGKEY)
--and msg.GLOBAL_TRANSACTION_ID='%asdf%'
--and msg.event_timestamp like '2018-11-18 0%'
--and (msg.msgflow_name like '%InsertUpdateCustomer%' or msg.msgflow_name like '%oService%')
--and msg.event_timestamp>'2018-11-28 04:37:00.000'
--and msg.event_timestamp<'2018-11-28 04:37:40.000'
--and (bd.data like '%MTU0MjU1OTA1NjcwMg%')
and msg.GLOBAL_TRANSACTION_ID = 'cdf68edc-d3d6-42e3-98a6-e183ef5c618c'
-- and rownum<100
order by msg.event_timestamp desc; 
 
 
 
select msg.GLOBAL_TRANSACTION_ID, PARENT_TRANSACTION_ID, LOCAL_TRANSACTION_ID, msg.WMB_MSGKEY, msg.EVENT_TIMESTAMP, msg.has_bitstream, msg.has_exception, msg.has_userdata, msg.event_srcaddr, msg.exgrp_name, msg.msgflow_name, detail, bd.DATA, bd.ENCODING
from WMB_MSGS msg,
     WMB_BINARY_DATA bd
where (msg.WMB_MSGKEY = bd.WMB_MSGKEY)
--and msg.GLOBAL_TRANSACTION_ID='%asdf%'
--and msg.event_timestamp like '2018-11-18 0%'
--and (msg.msgflow_name like '%InsertUpdateCustomer%' or msg.msgflow_name like '%oService%')
--and msg.event_timestamp>'2018-11-28 04:37:00.000'
--and msg.event_timestamp<'2018-11-28 04:37:40.000'
--and (bd.data like '%MTU0MjU1OTA1NjcwMg%')
and msg.GLOBAL_TRANSACTION_ID = 'e02de293-da24-4099-aabb-777628f041e5'
-- and rownum<100
order by msg.event_timestamp desc; 
